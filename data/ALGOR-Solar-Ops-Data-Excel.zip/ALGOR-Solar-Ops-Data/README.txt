Solar Module Manufacturing — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR); power in kW / MW (module rated power).
Period: Apr 2024 - Oct 2026 (Indian financial years; FY 2026-27 to date). Data as of 31 Oct 2026.

Tables:
  prod_monthly: 236 rows
  bins_monthly: 1,180 rows
  defects_monthly: 2,360 rows
  down_st_monthly: 1,360 rows
  down_rs_monthly: 988 rows
  sales_monthly: 528 rows
  fg_monthly: 131 rows
  inv_monthly: 372 rows
  budget_monthly: 62 rows
  shift_production_log: 10,047 rows
  stoppage_event_log: 13,353 rows
  reject_register_sample: 3,470 rows
  dispatch_register_sample: 2,206 rows
  daily_critical_stock: 4,880 rows
  daily_site_dispatch_fg: 1,158 rows
  materials_monthly_position: 628 rows
